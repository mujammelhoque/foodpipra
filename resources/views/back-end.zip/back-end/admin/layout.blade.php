
@include('back-end.admin.layout-partial.header')
<div class="wrapper">
    @include('back-end.admin.layout-partial.navbar')
    @include('back-end.admin.layout-partial.sidebar')

<div class="content-wrapper">
        @yield('content')
</div>
 <!-- /.content-wrapper -->

 @include('back-end.admin.layout-partial.footer')
</div>
<!-- ./wrapper -->
@include('back-end.admin.layout-partial.footer_url')☻

