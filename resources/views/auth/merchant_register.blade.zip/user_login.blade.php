@extends('front-end.layout')
@section('content')
     <header class="header">
        @include('front-end.content-partial.top&_mobile_header')
        @include('front-end.content-partial.header')
        @include('front-end.content-partial.navbar')
        @include('front-end.content-partial.mobile_search_sidebar')
        
    </header>
    <main class="no-main">
{{-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Login') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> --}}
{{--  --}}
<section class="section--login">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-6">
                <div class="login__box">
                    <div class="login__header">
                        <h3 class="login__login">LOGIN</h3>
                        <h3 > <span class="login__register"> OR</span> <a href="{{ route('register') }}"><strong style="color: green" >REGISTER</strong></a> </h3>
                    </div>
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                    <div class="login__content">
                        <div class="login__label">Login to your account.</div>
                        <div class="input-group">
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" placeholder="Username/ Email" required autocomplete="email" autofocus>
                            
                            @error('email')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                            {{-- <input class="form-control" type="email" name="email" placeholder="Username/ Email"> --}}
                        </div>
                        <div class="input-group group-password">

                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" placeholder="Password" required autocomplete="current-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror                            
                           
                        </div>
                        <div class="input-group form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                            <label class="form-check-label" for="remember">
                                {{ __('Remember Me') }}
                            </label>
                           
                        </div>
                   
                        <button type="submit" class="btn btn-login">
                            {{ __('Login') }}
                        </button>
                        @if (Route::has('password.request'))
                        <a class="btn btn-link" href="{{ route('password.request') }}">
                            {{ __('Forgot Your Password?') }}
                        </a>
                    @endif
                    </div>
                    </form>
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <h3 class="login__title">Advantages Of Becoming A Member</h3>
                <p class="login__description"> <b>FoodPipra Buyer Protection </b>has you covered from click to delivery.<br>Sign up or sign in and you will be able to: </p>
                <div class="login__orther">
                    <p> <i class="icon-truck"></i>Easily Track Orders, Hassle free Returns</p>
                    <p> <i class="icon-alarm2"></i>Get Relevant Alerts and Recommendation</p>
                    <p><i class="icon-star"></i>Wishlist, Reviews, Ratings and more.</p>
                </div>
                <div class="login__vourcher">
                    <div class="vourcher-money"><span class="unit">tk</span><span class="number">550</span></div>
                    <div class="vourcher-content">
                        <h4 class="vourcher-title">GIFT VOURCHER FOR FISRT PURCHASE</h4>
                        <p>We give tk 550 as a small gift for your first purchase.<br>Welcome to Farmart Market!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</main>
@include('front-end.content-partial.footer')
@include('front-end.content-partial.m_foot_cat_nav')
@endsection

